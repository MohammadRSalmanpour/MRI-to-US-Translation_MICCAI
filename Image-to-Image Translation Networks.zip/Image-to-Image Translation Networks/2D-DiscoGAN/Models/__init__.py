from Models.architectures.discogan import DiscoGAN
from Models.architectures.gcgan import GcGAN
from Models.architectures.travelgan import TraVeLGAN

from Models.common import parsers, datasets, callbacks
